#!/usr/bin/env python

print "setup ok!"
